"""
driver_monitoring/src/detectors.py

Four detection modules for the Driver Drowsiness & Distraction System:
  1. EAR  — Eye Aspect Ratio (drowsiness via eye closure)
  2. MAR  — Mouth Aspect Ratio (yawning)
  3. HeadPoseDetector — pitch/yaw/roll via solvePnP
  4. PhoneDetector    — YOLOv8-based phone/object detection
"""

import cv2
import numpy as np
import mediapipe as mp
from scipy.spatial import distance as dist
from dataclasses import dataclass, field
from typing import Optional, Tuple, List
import time


# ─────────────────────────────────────────────
#  MediaPipe landmark index maps
# ─────────────────────────────────────────────

# EAR: 6-point eye landmarks (top/bottom pairs)
RIGHT_EYE_EAR = [33, 160, 158, 133, 153, 144]
LEFT_EYE_EAR  = [362, 385, 387, 263, 373, 380]

# MAR: outer/inner lip landmarks
MOUTH_MAR = [61, 291, 82, 87, 312, 317, 78, 308, 13, 14]

# Head pose: 6 canonical 3D–2D correspondences
MODEL_POINTS_3D = np.array([
    [0.0, 0.0, 0.0],           # Nose tip        (landmark 1)
    [0.0, -330.0, -65.0],      # Chin            (landmark 8)
    [-225.0, 170.0, -135.0],   # Left eye corner (landmark 36)
    [225.0, 170.0, -135.0],    # Right eye corner(landmark 45)
    [-150.0, -150.0, -125.0],  # Mouth left      (landmark 48)
    [150.0, -150.0, -125.0],   # Mouth right     (landmark 54)
], dtype=np.float64)

# Corresponding MediaPipe landmark indices
HEAD_POSE_IDX = [1, 152, 226, 446, 57, 287]


@dataclass
class DetectionResult:
    """Unified output from all detectors in a single frame."""
    # EAR
    ear: float = 1.0
    left_ear: float = 1.0
    right_ear: float = 1.0
    eye_closed: bool = False
    eye_closed_frames: int = 0

    # MAR
    mar: float = 0.0
    yawning: bool = False
    yawn_frames: int = 0

    # Head pose
    pitch: float = 0.0   # up/down  (positive = down)
    yaw: float = 0.0     # left/right
    roll: float = 0.0    # tilt
    head_distracted: bool = False

    # Phone detection
    phone_detected: bool = False
    phone_confidence: float = 0.0
    phone_bbox: Optional[Tuple] = None

    # Overall
    alert_level: int = 0   # 0=OK, 1=warning, 2=critical
    alert_reason: List[str] = field(default_factory=list)
    fps: float = 0.0


# ─────────────────────────────────────────────
#  1. EAR Module
# ─────────────────────────────────────────────

class EARDetector:
    """
    Eye Aspect Ratio detector.

    EAR = (|p2-p6| + |p3-p5|) / (2 * |p1-p4|)
    Falls close to 0 when eye is closed.

    Thresholds:
      ear_threshold  – below this → eye closed
      consec_frames  – frames closed before alert
    """

    def __init__(self, ear_threshold: float = 0.25, consec_frames: int = 15):
        self.ear_threshold = ear_threshold
        self.consec_frames = consec_frames
        self._counter = 0

    @staticmethod
    def _eye_aspect_ratio(landmarks, eye_idx, img_w, img_h) -> float:
        pts = np.array([
            [landmarks[i].x * img_w, landmarks[i].y * img_h]
            for i in eye_idx
        ])
        A = dist.euclidean(pts[1], pts[5])
        B = dist.euclidean(pts[2], pts[4])
        C = dist.euclidean(pts[0], pts[3])
        return (A + B) / (2.0 * C + 1e-6)

    def process(self, landmarks, img_w: int, img_h: int, result: DetectionResult):
        left  = self._eye_aspect_ratio(landmarks, LEFT_EYE_EAR,  img_w, img_h)
        right = self._eye_aspect_ratio(landmarks, RIGHT_EYE_EAR, img_w, img_h)
        ear   = (left + right) / 2.0

        result.left_ear  = round(left, 3)
        result.right_ear = round(right, 3)
        result.ear       = round(ear, 3)

        if ear < self.ear_threshold:
            self._counter += 1
        else:
            self._counter = max(0, self._counter - 1)

        result.eye_closed_frames = self._counter
        result.eye_closed = self._counter >= self.consec_frames

        if result.eye_closed:
            result.alert_reason.append('eyes_closed')

    def reset(self):
        self._counter = 0


# ─────────────────────────────────────────────
#  2. MAR Module (Yawning)
# ─────────────────────────────────────────────

class MARDetector:
    """
    Mouth Aspect Ratio detector.

    MAR = vertical_mouth_opening / horizontal_mouth_width
    High MAR → yawning.
    """

    def __init__(self, mar_threshold: float = 0.6, consec_frames: int = 20):
        self.mar_threshold = mar_threshold
        self.consec_frames = consec_frames
        self._counter = 0

    @staticmethod
    def _mouth_aspect_ratio(landmarks, img_w, img_h) -> float:
        # Vertical distances (3 pairs)
        pts = lambda i: np.array([landmarks[i].x * img_w, landmarks[i].y * img_h])

        # Upper lip – lower lip vertical
        A = dist.euclidean(pts(82),  pts(87))   # left vertical
        B = dist.euclidean(pts(312), pts(317))  # right vertical
        C = dist.euclidean(pts(13),  pts(14))   # center vertical

        # Horizontal: left to right corner
        D = dist.euclidean(pts(61), pts(291))

        return (A + B + C) / (3.0 * D + 1e-6)

    def process(self, landmarks, img_w: int, img_h: int, result: DetectionResult):
        mar = self._mouth_aspect_ratio(landmarks, img_w, img_h)
        result.mar = round(mar, 3)

        if mar > self.mar_threshold:
            self._counter += 1
        else:
            self._counter = max(0, self._counter - 1)

        result.yawn_frames = self._counter
        result.yawning = self._counter >= self.consec_frames

        if result.yawning:
            result.alert_reason.append('yawning')

    def reset(self):
        self._counter = 0


# ─────────────────────────────────────────────
#  3. Head Pose Estimator
# ─────────────────────────────────────────────

class HeadPoseDetector:
    """
    Head pose estimation using solvePnP on 6 MediaPipe landmarks.

    Angles (degrees):
      pitch > 0  → head tilted down (looking at phone/lap)
      pitch < 0  → head tilted up
      yaw   > 0  → head turned right
      yaw   < 0  → head turned left
      roll        → head tilted sideways

    Thresholds (conservative for driving):
      pitch_threshold: looking down > 20°  (phone-in-lap scenario)
      yaw_threshold  : turned > 30°        (looking away from road)
    """

    def __init__(
        self,
        pitch_threshold: float = 20.0,
        yaw_threshold: float = 30.0,
        consec_frames: int = 10
    ):
        self.pitch_threshold = pitch_threshold
        self.yaw_threshold   = yaw_threshold
        self.consec_frames   = consec_frames
        self._counter        = 0
        self._camera_matrix  = None
        self._dist_coeffs    = np.zeros((4, 1))

    def _get_camera_matrix(self, img_w: int, img_h: int) -> np.ndarray:
        if (self._camera_matrix is None or
                self._camera_matrix[0, 2] != img_w / 2):
            focal = img_w
            self._camera_matrix = np.array([
                [focal, 0,     img_w / 2],
                [0,     focal, img_h / 2],
                [0,     0,     1        ]
            ], dtype=np.float64)
        return self._camera_matrix

    def process(self, landmarks, img_w: int, img_h: int, result: DetectionResult):
        img_points = np.array([
            [landmarks[i].x * img_w, landmarks[i].y * img_h]
            for i in HEAD_POSE_IDX
        ], dtype=np.float64)

        camera_matrix = self._get_camera_matrix(img_w, img_h)

        success, rvec, tvec = cv2.solvePnP(
            MODEL_POINTS_3D, img_points,
            camera_matrix, self._dist_coeffs,
            flags=cv2.SOLVEPNP_ITERATIVE
        )

        if not success:
            return

        # Convert rotation vector to Euler angles
        rmat, _ = cv2.Rodrigues(rvec)
        angles, _, _, _, _, _ = cv2.RQDecomp3x3(rmat)

        pitch = angles[0]
        yaw   = angles[1]
        roll  = angles[2]

        result.pitch = round(pitch, 1)
        result.yaw   = round(yaw, 1)
        result.roll  = round(roll, 1)

        distracted = (
            abs(pitch) > self.pitch_threshold or
            abs(yaw)   > self.yaw_threshold
        )

        if distracted:
            self._counter += 1
        else:
            self._counter = max(0, self._counter - 1)

        result.head_distracted = self._counter >= self.consec_frames
        if result.head_distracted:
            reason = []
            if abs(pitch) > self.pitch_threshold:
                reason.append(f'head_down_{pitch:.0f}deg')
            if abs(yaw) > self.yaw_threshold:
                reason.append(f'head_turned_{yaw:.0f}deg')
            result.alert_reason.extend(reason)

    def draw_axes(self, frame, landmarks, img_w: int, img_h: int):
        """Draw 3D pose axes on frame for visualization."""
        img_points = np.array([
            [landmarks[i].x * img_w, landmarks[i].y * img_h]
            for i in HEAD_POSE_IDX
        ], dtype=np.float64)

        camera_matrix = self._get_camera_matrix(img_w, img_h)
        success, rvec, tvec = cv2.solvePnP(
            MODEL_POINTS_3D, img_points,
            camera_matrix, self._dist_coeffs
        )
        if not success:
            return

        axis_length = 100
        axes_3d = np.float32([
            [axis_length, 0, 0],
            [0, axis_length, 0],
            [0, 0, axis_length],
            [0, 0, 0]
        ])
        projected, _ = cv2.projectPoints(
            axes_3d, rvec, tvec, camera_matrix, self._dist_coeffs
        )
        projected = projected.astype(int)
        nose = tuple(projected[3].ravel())
        cv2.line(frame, nose, tuple(projected[0].ravel()), (0, 0, 255), 2)   # X red
        cv2.line(frame, nose, tuple(projected[1].ravel()), (0, 255, 0), 2)   # Y green
        cv2.line(frame, nose, tuple(projected[2].ravel()), (255, 0, 0), 2)   # Z blue

    def reset(self):
        self._counter = 0


# ─────────────────────────────────────────────
#  4. Phone Detector (YOLOv8)
# ─────────────────────────────────────────────

class PhoneDetector:
    """
    YOLOv8-based phone/distraction detector.

    Uses pretrained COCO weights (cell phone = class 67).
    Can be fine-tuned on a custom driving dataset.

    confidence_threshold: minimum score to count as detection
    """

    COCO_PHONE_CLASS = 67  # 'cell phone' in MS-COCO

    def __init__(
        self,
        model_path: str = 'yolov8n.pt',
        confidence_threshold: float = 0.45,
        iou_threshold: float = 0.45,
        device: str = 'cpu'
    ):
        self.conf = confidence_threshold
        self.iou  = iou_threshold
        self.device = device
        self.model = None
        self._model_path = model_path

    def load(self):
        """Lazy-load YOLO model."""
        from ultralytics import YOLO
        self.model = YOLO(self._model_path)
        self.model.to(self.device)
        print(f'[PhoneDetector] Loaded: {self._model_path} on {self.device}')

    def process(self, frame: np.ndarray, result: DetectionResult):
        if self.model is None:
            self.load()

        preds = self.model(
            frame,
            conf=self.conf,
            iou=self.iou,
            classes=[self.COCO_PHONE_CLASS],
            verbose=False
        )

        result.phone_detected  = False
        result.phone_confidence = 0.0
        result.phone_bbox = None

        for det in preds:
            boxes = det.boxes
            if boxes is None or len(boxes) == 0:
                continue
            for box in boxes:
                cls = int(box.cls[0])
                conf = float(box.conf[0])
                if cls == self.COCO_PHONE_CLASS and conf > result.phone_confidence:
                    result.phone_detected   = True
                    result.phone_confidence = round(conf, 3)
                    result.phone_bbox = tuple(box.xyxy[0].int().tolist())

        if result.phone_detected:
            result.alert_reason.append(
                f'phone_detected_{result.phone_confidence:.0%}'
            )

    def draw(self, frame: np.ndarray, result: DetectionResult):
        """Draw phone bounding box on frame."""
        if result.phone_detected and result.phone_bbox:
            x1, y1, x2, y2 = result.phone_bbox
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
            label = f'Phone {result.phone_confidence:.0%}'
            cv2.putText(frame, label, (x1, y1 - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
